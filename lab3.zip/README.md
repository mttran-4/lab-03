# CMPUT 301 : Lab 3 Participation Exercise

## References and Resources

List any resources used here, or simply put `N/A` if not applicable.

## Verbal Collaboration

| Student Name | CCID      |
| ------------ | --------- |
| `student`    | `student` |
| `<Add more>` | `<CCID>`  |
